<?php

namespace App\Containers\User\Tests;

use App\Containers\User\Tests\TestCase as BaseTestCase;

/**
 * Class WebTestCase.
 *
 * This is the container WEB TestCase class. Use this class to add your container specific WEB related helper functions.
 */
class WebTestCase extends BaseTestCase
{
    // ..
}
