<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
<h3>Bienvenu {{$name}}</h3>
<div>
    Merci de rejoindre la communauté.
</div>
</body>
</html>
