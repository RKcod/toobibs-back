<?php

namespace App\Containers\User\Data\Repositories;

use App\Ship\Parents\Repositories\Repository;

/**
 * Class UserRepository.
 *
 * @author Mahmoud Zalt <mahmoud@zalt.me>
 */
class UserRepository extends Repository
{

    /**
     * @var array
     */
    protected $fieldSearchable = [
        'first_name'       => 'like',
        'last_name'       => 'like',
        'id'         => '=',
        'center_id'         => '=',
        'display_home'         => '=',
        'email'      => '=',
        'confirmed'  => '=',
        'do_teleconsult'  => '=',
        'user_type'  => '=',
        'address'  => '=',
        'speciality'  => 'like',
        'created_at' => 'like',
    ];

}
